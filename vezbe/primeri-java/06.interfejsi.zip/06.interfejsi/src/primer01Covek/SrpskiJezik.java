package primer01Covek;

public interface SrpskiJezik {
	void zdravo();
	void dovidjenja();
	void hvala();
}
