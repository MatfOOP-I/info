package primer01Covek;

public interface EngleskiJezik {
	void hello();
	void goodbye();
	void thanks();
}
