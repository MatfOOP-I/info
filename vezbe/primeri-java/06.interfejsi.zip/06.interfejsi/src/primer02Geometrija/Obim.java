package primer02Geometrija;

public interface Obim {
	double getObim();
}
