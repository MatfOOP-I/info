package primer02Geometrija;

public interface Povrsina {
	double getPovrsina();
}
