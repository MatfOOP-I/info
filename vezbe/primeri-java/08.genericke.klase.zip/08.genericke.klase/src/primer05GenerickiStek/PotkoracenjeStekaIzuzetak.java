package primer05GenerickiStek;

public class PotkoracenjeStekaIzuzetak extends RuntimeException
{
}
