public interface Ispis {
    void ispisi();
}
