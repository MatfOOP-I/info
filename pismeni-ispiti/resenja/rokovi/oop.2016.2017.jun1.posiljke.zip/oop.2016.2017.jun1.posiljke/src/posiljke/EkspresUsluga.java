package posiljke;

public enum EkspresUsluga {
	ODMAH, DANAS, SUTRA_12, SUTRA_19;
}
