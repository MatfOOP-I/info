public interface Izleciv {
    void leci(int brojDana);
    boolean izlecen();
}
