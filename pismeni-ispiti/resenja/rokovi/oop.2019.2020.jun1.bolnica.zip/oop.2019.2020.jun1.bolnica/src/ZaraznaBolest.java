public abstract class ZaraznaBolest {
    private int duzinaBolesti;

    public ZaraznaBolest(int duzinaBolesti){
        this.duzinaBolesti = duzinaBolesti;
    }

    public int getDuzinaBolesti() {
        return duzinaBolesti;
    }

    public void setDuzinaBolesti(int duzinaBolesti) {
        this.duzinaBolesti = duzinaBolesti;
    }
}
