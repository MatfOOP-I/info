package rs.math.oop.g11.p01.izuzeciIndeksVanGranica;

public class IndeksVanGranica {

	public static void main(String[] args) {
		int a[] = new int[2];
		System.out.println("Приступам елементу:" + a[3]);
	}
}
