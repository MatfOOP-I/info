package rs.math.oop.g08.p02.kreiranjeObjekata;

class KreiranjeObjekata{

	   public static void main(String[] args) {
	       Zaposleni z1 = new Zaposleni();
	       Zaposleni z2 = new Zaposleni();

	       String s1 = new String();
	       String s2 = new String("Браћа Бамбалић");
	       String s3 = s2;
	    }
	}
