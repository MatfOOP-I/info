package rs.math.oop.g08.p02.kreiranjeObjekata;

class Zaposleni {
    String imePrezime;
    double plata;
}

