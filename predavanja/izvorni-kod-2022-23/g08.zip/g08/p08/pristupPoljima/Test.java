package rs.math.oop.g08.p08.pristupPoljima;

public class Test {

	int polje1;
	static int polje2;
	
	void metod1() {
		
	}
	
	static void metod2() {
		
	}
	
	static void metod3() {
		// polje1 = 10; // не компајлира се
		polje2 = 20;
		// metod1(); // не компајлира се
		metod2();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
