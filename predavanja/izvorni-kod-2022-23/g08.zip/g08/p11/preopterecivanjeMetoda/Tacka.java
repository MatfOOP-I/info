package rs.math.oop.g08.p11.preopterecivanjeMetoda;

public class Tacka {
	int x;
	int y;
}
