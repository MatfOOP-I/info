package rs.math.oop.g08.p06.pripadnostKlasi;

public class Kutija {
	int visina;
	int sirina;
	int dubina;
}
