package rs.math.oop.g03.p01.imperativnaParadigma;

class ImperativnoNzd {
    // улазна тачка програма
    public static void main(String[] args) {
        // бројеви чији се НЗД тражи
        int prviBroj = 48;
        int drugiBroj = 120;
        int treciBroj = 56;
        // приказ бројева чији се НЗД тражи
        System.out.println("Први број је " + prviBroj);
        System.out.println("Други број је " + drugiBroj);
        System.out.println("Трећи број је " + treciBroj);
        // одређивање НЗД за први и други број
        nzdPrviDrugi: for (;;) {
            if (prviBroj == drugiBroj)
                break nzdPrviDrugi;
            // размени бројеве тако да други број буде већи од првог
            if (prviBroj > drugiBroj) {
                int privremeni = prviBroj;
                prviBroj = drugiBroj;
                drugiBroj = privremeni;
            }
            // нови пар бројева су дотадашњи мањи и разлика између већег и мањег
            drugiBroj = drugiBroj - prviBroj;
        }
        // одређивање НЗД за НЗД прва два броја и трећи број
        nzdNadPrvaDvaTreci: for (;;) {
            // ако су бројеви исти, НЗД је ма који од њих
            if (prviBroj == treciBroj)
                break nzdNadPrvaDvaTreci;
            // размени бројеве тако да трећи број буде већи од првог
            if (prviBroj > treciBroj) {
                int privremeni = prviBroj;
                prviBroj = treciBroj;
                treciBroj = privremeni;
            }
            // ако мањи број дели већи број, тада је мањи број НЗД
            if (treciBroj % prviBroj == 0)
                break nzdNadPrvaDvaTreci;
            // "преживљавају" мањи од два броја и остатак при дељењу
            treciBroj = treciBroj % prviBroj;
        }
        // приказ резултата
        System.out.println("НЗД ова три броја је " + prviBroj);
    }
}
