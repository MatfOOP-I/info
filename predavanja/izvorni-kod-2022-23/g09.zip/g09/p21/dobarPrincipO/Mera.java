package rs.math.oop.g09.p21.dobarPrincipO;

public interface Mera {
   double povrsina();
}
