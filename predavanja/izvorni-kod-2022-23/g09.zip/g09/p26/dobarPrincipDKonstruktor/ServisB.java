package rs.math.oop.g09.p26.dobarPrincipDKonstruktor;

public class ServisB implements Servis {

   @Override
   public String getInfo() {
      return "Информације о сервису ServisB";
   }
}
