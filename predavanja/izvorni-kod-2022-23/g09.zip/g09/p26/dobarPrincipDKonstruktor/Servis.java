package rs.math.oop.g09.p26.dobarPrincipDKonstruktor;

public interface Servis {
   String getInfo();
}
