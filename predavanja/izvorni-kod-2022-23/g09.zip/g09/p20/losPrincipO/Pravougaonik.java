package rs.math.oop.g09.p20.losPrincipO;

public class Pravougaonik {
   private double sirina;
   private double visina;

   public Pravougaonik(double sirina, double visina) {
      this.sirina = sirina;
      this.visina = visina;
   }

   public double uzmiSirinu() {
      return sirina;
   }

   public double uzmiVisinu() {
      return visina;
   }
}
