package rs.math.oop.g09.p24.dobarPrincipI;

import static java.lang.System.out;

public class OnLajnPlacanje implements Placanje {

   @Override
   public void platiPorudzbinu() {
      out.println("Realizuje se on-lajn placanje za narudzbinu!");
   }
}
