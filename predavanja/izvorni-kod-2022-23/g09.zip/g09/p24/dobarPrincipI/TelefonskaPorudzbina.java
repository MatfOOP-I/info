package rs.math.oop.g09.p24.dobarPrincipI;

import static java.lang.System.out;

public class TelefonskaPorudzbina implements Porudzbina {

   @Override
   public void prihvatiPorudzbinu() {
      out.println("Realizuje se prihvatanje telefonske poruzbine!");
   }

}
