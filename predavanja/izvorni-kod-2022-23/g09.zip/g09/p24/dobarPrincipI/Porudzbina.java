package rs.math.oop.g09.p24.dobarPrincipI;

public interface Porudzbina {
   public void prihvatiPorudzbinu();
}
