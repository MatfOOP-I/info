package rs.math.oop.g09.p24.dobarPrincipI;

import static java.lang.System.out;

public class LicnoPlacanje implements Placanje {


   @Override
   public void platiPorudzbinu() {
      out.println("Realizuje se licno placanje za narudzbinu!");
   }
}
