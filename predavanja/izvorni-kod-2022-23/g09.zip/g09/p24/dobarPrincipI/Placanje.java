package rs.math.oop.g09.p24.dobarPrincipI;

public interface Placanje {
   public void platiPorudzbinu();
}
