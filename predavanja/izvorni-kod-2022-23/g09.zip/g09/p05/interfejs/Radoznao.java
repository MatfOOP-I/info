package rs.math.oop.g09.p05.interfejs;

public interface Radoznao {

      void prikaziUpit();
      String tekstUpita();
}
