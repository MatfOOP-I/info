package rs.math.oop.g09.p25.losPrincipD;

public class ServisB {
   public String getInfo() {
      return "Информације о сервису ServisB";
   }
}
