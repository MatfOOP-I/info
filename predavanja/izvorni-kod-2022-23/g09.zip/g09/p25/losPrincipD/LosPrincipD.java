package rs.math.oop.g09.p25.losPrincipD;

public class LosPrincipD {

   public static void main(String[] args){
      KlijentA ka = new KlijentA();
      ka.uradiNesto();
   }

}
