package rs.math.oop.g09.p23.losPrincipI;

public interface Restoran
   {
      public void prihvatiOnLajnPorudzbinu();
      public void prihvatiTelefonskuPorudzbinu();
      public void platiOnLajn();
      public void staniURedZaLicnuPorudzbinu();
      public void platiLicno();
   }
