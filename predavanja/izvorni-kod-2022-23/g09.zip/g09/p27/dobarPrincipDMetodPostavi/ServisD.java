package rs.math.oop.g09.p27.dobarPrincipDMetodPostavi;

public class ServisD implements Servis {

   @Override
   public String getInfo() {
      return "Информације о сервису ServisD";
   }
}
