package rs.math.oop.g09.p27.dobarPrincipDMetodPostavi;

public interface Klijent {
   void uradiNesto();
}
