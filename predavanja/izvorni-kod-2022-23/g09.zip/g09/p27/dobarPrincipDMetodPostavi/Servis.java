package rs.math.oop.g09.p27.dobarPrincipDMetodPostavi;

public interface Servis {
   String getInfo();
}
