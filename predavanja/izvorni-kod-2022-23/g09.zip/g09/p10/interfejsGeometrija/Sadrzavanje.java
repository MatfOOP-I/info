package rs.math.oop.g09.p10.interfejsGeometrija;

public interface Sadrzavanje {
    boolean sadrzi(Tacka t);
}
