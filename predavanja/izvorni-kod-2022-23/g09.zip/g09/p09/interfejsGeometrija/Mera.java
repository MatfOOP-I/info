package rs.math.oop.g09.p09.interfejsGeometrija;

public interface Mera {

   double obim();

   double povrsina();
}
