package rs.math.oop.g09.p09.interfejsGeometrija;

public interface MeraOblikSadrzavanje extends Mera, Oblik, Sadrzavanje{
}
