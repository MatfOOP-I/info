package rs.math.oop.g09.p09.interfejsGeometrija;

public interface Sadrzavanje {
    boolean sadrzi(Tacka t);
}
