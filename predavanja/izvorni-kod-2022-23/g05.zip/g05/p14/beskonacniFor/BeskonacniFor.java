package rs.math.oop.g05.p14.beskonacniFor;

public class BeskonacniFor {

	public static void main(String[] args) {
		long n=0;
		for(;;)
			n++;
		//System.out.println(n); 
		// наредба исписа изнад се неће никад десити 
		// па и компајлер указује на грешку, 
		// стога је наредба коментарисана
	}
}
