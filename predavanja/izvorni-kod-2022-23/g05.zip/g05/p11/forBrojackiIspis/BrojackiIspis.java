package rs.math.oop.g05.p11.forBrojackiIspis;

public class BrojackiIspis {

	public static void main(String[] args) {
		 for (int i=1; i<=10; i++)
			  System.out.println("Ана воли програмирање");
	}
}
