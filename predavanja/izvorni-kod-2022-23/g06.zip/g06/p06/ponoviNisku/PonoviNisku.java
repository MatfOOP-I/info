package rs.math.oop.g06.p06.ponoviNisku;

public class PonoviNisku {

	public static void main(String[] args) {
		String s = "Тест";
		int n = 10;
		String sn = "";
		for(int i=0; i<n; i++)
			sn+=s;
		System.out.println(sn);
	}
}
