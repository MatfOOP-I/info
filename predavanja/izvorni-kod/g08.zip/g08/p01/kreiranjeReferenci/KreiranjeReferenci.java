package rs.math.oop.g08.p01.kreiranjeReferenci;

class KreiranjeReferenci {

	public static void main(String[] args) {
		Zaposleni z1;
		Zaposleni z2;

		String s1;
		String s2;
		String s3;
	}
}
