package rs.math.oop.g08.p01.kreiranjeReferenci;

class Zaposleni {
    String imePrezime;
    double plata;
}

