package rs.math.oop.g08.p05a.pripadnostKlasi;

public class Kutija {
	int visina;
	int sirina;
	int dubina;
}
