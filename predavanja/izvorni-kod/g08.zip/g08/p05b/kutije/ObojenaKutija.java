package rs.math.oop.g08.p05b.kutije;

public class ObojenaKutija extends Kutija{
	String boja;
}
