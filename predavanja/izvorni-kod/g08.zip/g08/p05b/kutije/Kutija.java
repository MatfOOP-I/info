package rs.math.oop.g08.p05b.kutije;

public class Kutija {
	int visina;
	int sirina;
	int dubina;
}
