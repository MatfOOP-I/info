package rs.math.oop.g08.p05.poredjenjeOperatoromJednako;

public class Kutija {
	int visina;
	int sirina;
	int dubina;
}
