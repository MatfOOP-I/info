package rs.math.oop.g08.p19.packageModifikator.podpaket2;

// коментарисани редови су разлог немогућности компилације
//import rs.math.oop.g08.p19.packageModifikator.podpaket1.A;

public class C {
	
	void testirajA() {
//		A a = new A();
//		a.polje = 20;
//		a.metod();
	}
	
	public static void main(String[] args) {
		// A a = new A();
		// a.polje = 20;
		// a.metod();	
	}
}
