package rs.math.oop.g08.p10.preopterecivanjeMetoda;

public class Tacka {
	int x;
	int y;
}
