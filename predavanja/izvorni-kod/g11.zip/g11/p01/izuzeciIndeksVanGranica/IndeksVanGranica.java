package rs.math.oop.g11.p01.izuzeciIndeksVanGranica;

public class IndeksVanGranica {

	public static void main(String[] args) {
		System.out.println("Почетак");
		int a[] = new int[22];
		System.out.println("Приступам елементу:" + a[-3]);
		System.out.println("Готово");
	}
}
