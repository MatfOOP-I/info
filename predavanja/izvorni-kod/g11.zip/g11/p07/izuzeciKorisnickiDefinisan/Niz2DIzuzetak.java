package rs.math.oop.g11.p07.izuzeciKorisnickiDefinisan;

public class Niz2DIzuzetak extends Exception {

	public Niz2DIzuzetak(String poruka) {
		super(poruka);
	}
}