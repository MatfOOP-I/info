package rs.math.oop.g12.p02.enumiBrojDanaUMesecu;

public enum MesecKalendarski {
    JANUAR, FEBRUAR, MART, APRIL, MAJ, JUN, 
    JUL, AVGUST, SEPTEMBAR, OKTOBAR, NOVEMBAR, DECEMBAR;
}