package rs.math.oop.g12.p01.enumiDaniUNedelji;

enum DanUNedelji {
	PONEDELJAK, UTORAK, SREDA, CETVRTAK, PETAK, SUBOTA, NEDELJA;
}


