package rs.math.oop.g18.p01.funkcionalniInterfejsCustom;

@FunctionalInterface
public interface Interfejs2
{
    boolean test(int input);
}
