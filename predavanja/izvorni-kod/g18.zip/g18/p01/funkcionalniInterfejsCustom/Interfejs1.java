package rs.math.oop.g18.p01.funkcionalniInterfejsCustom;

public interface Interfejs1
{
    boolean test(int input);
}

