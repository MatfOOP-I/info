package rs.math.oop.g18.p03.pretragaPrikazCustomInterfejsOsoba;

public interface KriterijumPretrage<E> {
    boolean proveri(E element);
}
