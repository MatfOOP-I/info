package rs.math.oop.g18.p02.funkcionalniInterfejsPodrazumevaniMetodi;

public class Vozilo {
    public void zaokretanje() {
        System.out.println("Vozilo::zaokrece");
    }
}
