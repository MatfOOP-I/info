package rs.math.oop.g09.p26.losPrincipD;

public class LosPrincipD {

   public static void main(String[] args){
      KlijentA ka = new KlijentA();
      ka.uradiNesto();
   }

}
