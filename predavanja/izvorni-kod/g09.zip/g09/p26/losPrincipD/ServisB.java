package rs.math.oop.g09.p26.losPrincipD;

public class ServisB {
   public String uzmiInfo() {
      return "Информације о сервису ServisB";
   }
}
