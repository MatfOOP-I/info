package rs.math.oop.g09.p09.interfejsGeometrija;

public interface Oblik {

   boolean jeKonveksan();

   boolean jeOgranicen();

}
