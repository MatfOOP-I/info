package rs.math.oop.g09.p06.interfejsImplementacija;

public interface Radoznao {

      void prikaziUpit();
      String tekstUpita();
}
