package rs.math.oop.g09.p30.dogadjaji;

public class Sunce {

    @Override
    public String toString(){
        return "SUNCE";
    }
}
