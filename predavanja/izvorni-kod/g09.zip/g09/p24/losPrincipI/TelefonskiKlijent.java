package rs.math.oop.g09.p24.losPrincipI;

public class TelefonskiKlijent {
   private String ime;
   private String adresa;
   private String brojTelefona;
   private Restoran hraniSe;

   public TelefonskiKlijent(String ime, String adresa, String brojTelefona, Restoran hraniSe) {
      this.ime = ime;
      this.adresa = adresa;
      this.brojTelefona = brojTelefona;
      this.hraniSe = hraniSe;
   }
}
