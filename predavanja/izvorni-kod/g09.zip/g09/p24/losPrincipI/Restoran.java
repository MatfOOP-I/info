package rs.math.oop.g09.p24.losPrincipI;

public interface Restoran
   {
      public void prihvatiOnLajnPorudzbinu();
      public void prihvatiTelefonskuPorudzbinu();
      public void platiOnLajn();
      public void staniURedZaLicnuPorudzbinu();
      public void platiLicno();
   }
