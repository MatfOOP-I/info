package rs.math.oop.g09.p24.losPrincipI;

public class LicnoDosaoKlijent {
   private String ime;
   private Restoran hraniSe;

   public LicnoDosaoKlijent(String ime, Restoran hraniSe) {
      this.ime = ime;
      this.hraniSe = hraniSe;
   }
}
