package rs.math.oop.g09.p25.dobarPrincipI;

public class LicnoDosaoKlijent {
   private String ime;
   private Porudzbina porudzbina;
   private Placanje placanje;

   public LicnoDosaoKlijent(String ime, Porudzbina porudzbina, Placanje placanje) {
      this.ime = ime;
      this.porudzbina = porudzbina;
      this.placanje = placanje;
   }
}
