package rs.math.oop.g09.p25.dobarPrincipI;

import static java.lang.System.out;

public class TelefonskaPorudzbina implements Porudzbina {

   @Override
   public void prihvatiPorudzbinu() {
      out.println("Реализује се прихватање телефонске поруџбине!");
   }

}
