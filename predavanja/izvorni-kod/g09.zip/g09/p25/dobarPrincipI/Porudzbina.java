package rs.math.oop.g09.p25.dobarPrincipI;

public interface Porudzbina {
   public void prihvatiPorudzbinu();
}
