package rs.math.oop.g09.p25.dobarPrincipI;

import static java.lang.System.out;

public class OnLajnPlacanje implements Placanje {

   @Override
   public void platiPorudzbinu() {
      out.println("Реализује се он-лајн плаћање за поруџбину!");
   }
}
