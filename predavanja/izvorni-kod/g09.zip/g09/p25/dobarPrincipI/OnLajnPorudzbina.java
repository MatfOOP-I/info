package rs.math.oop.g09.p25.dobarPrincipI;

import static java.lang.System.out;

public class OnLajnPorudzbina implements Porudzbina {
   @Override
   public void prihvatiPorudzbinu() {
      out.println("Реализује се постављање он-лајн поруџбине!");
   }

}
