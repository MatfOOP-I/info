package rs.math.oop.g09.p25.dobarPrincipI;

import static java.lang.System.out;

public class LicnoNapravljenaPorudzbina implements Porudzbina {

   @Override
   public void prihvatiPorudzbinu() {
      out.println("Реализује се прихватање лично направљене поруџбине!");
   }

}
