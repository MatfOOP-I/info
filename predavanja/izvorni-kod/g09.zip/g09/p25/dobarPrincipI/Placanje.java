package rs.math.oop.g09.p25.dobarPrincipI;

public interface Placanje {
   public void platiPorudzbinu();
}
