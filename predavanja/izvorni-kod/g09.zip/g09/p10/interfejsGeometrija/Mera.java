package rs.math.oop.g09.p10.interfejsGeometrija;

public interface Mera {

   double obim();

   double povrsina();
}
