package rs.math.oop.g09.p10.interfejsGeometrija;

public interface Oblik {

   boolean jeKonveksan();

   boolean jeOgranicen();

}
