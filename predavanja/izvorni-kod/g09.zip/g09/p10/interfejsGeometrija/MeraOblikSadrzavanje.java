package rs.math.oop.g09.p10.interfejsGeometrija;

public interface MeraOblikSadrzavanje extends Mera, Oblik, Sadrzavanje {
}
