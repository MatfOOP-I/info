package rs.math.oop.g09.p22.dobarPrincipO;

public interface Mera {
   double povrsina();
}
