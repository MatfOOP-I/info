package rs.math.oop.g09.p07.interfejsVise;

public interface Razuman
{
      void razmotriCinjenice();
      void definisiHipotezu();
}
