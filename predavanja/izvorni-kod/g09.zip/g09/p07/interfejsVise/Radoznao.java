package rs.math.oop.g09.p07.interfejsVise;

public interface Radoznao {

      void prikaziUpit();
      String tekstUpita();
}
