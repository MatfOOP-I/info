package rs.math.oop.g09.p28.dobarPrincipDMetodPostavi;

public class ServisC implements Servis {

   @Override
   public String uzmiInfo() {
      return "Информације о сервису ServisC";
   }
}
