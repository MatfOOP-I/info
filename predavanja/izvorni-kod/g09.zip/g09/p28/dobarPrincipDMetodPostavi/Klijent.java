package rs.math.oop.g09.p28.dobarPrincipDMetodPostavi;

public interface Klijent {
   void uradiNesto();
}
