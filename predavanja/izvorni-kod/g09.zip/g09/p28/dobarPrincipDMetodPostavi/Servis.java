package rs.math.oop.g09.p28.dobarPrincipDMetodPostavi;

public interface Servis {
   String uzmiInfo();
}
