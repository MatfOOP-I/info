package rs.math.oop.g09.p28.dobarPrincipDMetodPostavi;

public class ServisD implements Servis {

   @Override
   public String uzmiInfo() {
      return "ЏЏЏ";
   }
}
