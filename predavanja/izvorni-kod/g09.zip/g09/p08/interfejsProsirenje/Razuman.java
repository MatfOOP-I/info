package rs.math.oop.g09.p08.interfejsProsirenje;

public interface Razuman
{
      void razmotriCinjenice();

      void definisiHipotezu();
}
