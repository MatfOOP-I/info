package rs.math.oop.g09.p27.dobarPrincipDKonstruktor;

public interface Klijent {
   void uradiNesto();
}
