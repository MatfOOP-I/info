package rs.math.oop.g09.p27.dobarPrincipDKonstruktor;

public class ServisD implements Servis {

   @Override
   public String uzmiInfo() {
      return "ЏЏЏ";
   }
}
