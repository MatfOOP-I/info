package rs.math.oop.g09.p27.dobarPrincipDKonstruktor;

public class ServisB implements Servis {

   @Override
   public String uzmiInfo() {
      return "Информације о сервису ServisB";
   }
}
