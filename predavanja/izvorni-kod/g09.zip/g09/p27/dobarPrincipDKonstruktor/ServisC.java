package rs.math.oop.g09.p27.dobarPrincipDKonstruktor;

public class ServisC implements Servis {

   @Override
   public String uzmiInfo() {
      return "Информације о сервису ServisC";
   }
}
