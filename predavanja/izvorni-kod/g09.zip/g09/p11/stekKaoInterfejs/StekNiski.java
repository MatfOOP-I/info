package rs.math.oop.g09.p11.stekKaoInterfejs;

public interface StekNiski {
	void dodaj(String elem); // енг. push()
	String ukloni(); // енг. pop()
	int brojElemenata();
}
