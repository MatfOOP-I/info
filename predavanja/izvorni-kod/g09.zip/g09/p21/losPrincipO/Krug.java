package rs.math.oop.g09.p21.losPrincipO;

public class Krug {
   private double poluprecnik;

   public Krug(double poluprecnik) {
      this.poluprecnik = poluprecnik;
   }

   public double uzmiPoluprecnik() {
      return poluprecnik;
   }

}
