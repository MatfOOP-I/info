package rs.math.oop.g16.p06.ispitivanjeTipaAnalizaObjekta;


//покренути програм са аргументима виртуелне машине (VM):
// --add-opens java.base/java.util=ALL-UNNAMED
// --add-opens java.base/java.lang=ALL-UNNAMED
public class AnalizeRazlicitihObjekata {
   public static void main(String[] args) {
      int x = 5;
      System.out.println(new AnalizaObjekta().prikaz(x));
      System.out.println("---");

      double x1 = 5.6;
      System.out.println(new AnalizaObjekta().prikaz(x1));
      System.out.println("---");

      String s = "Marko Markovic";
      System.out.println(new AnalizaObjekta().prikaz(s));
      System.out.println("---");

      Zaposleni pera = new Zaposleni("Janko Jankovic", 8_000);
      System.out.println(new AnalizaObjekta().prikaz(pera));
      System.out.println("---");

      Direktor mika = new Direktor("Mika Petrovic", 8000, 4000);
      System.out.println(new AnalizaObjekta().prikaz(mika));
      System.out.println("---");

      Pair<String> mz = new Pair<>("mika", "zika");
      System.out.println(new AnalizaObjekta().prikaz(mz));
      System.out.println("---");

      Pair<Zaposleni> pm = new Pair<>(pera, mika);
      System.out.println(new AnalizaObjekta().prikaz(pm));
      System.out.println("---");

      int[] niz = {1, 2, 3, 4, 5};
      System.out.println(new AnalizaObjekta().prikaz(niz));
      System.out.println("---");

      Direktor m = new Direktor("Petar Petrоvic", 10_100, 0);
      m.postaviBonus(300);
      System.out.println(new AnalizaObjekta().prikaz(m));
      m.postaviBonus(700);
      System.out.println(new AnalizaObjekta().prikaz(m));
      System.out.println("---");

      Zaposleni[] osobe = {
            new Zaposleni("Zarko Zarkovic", 20_100),
            m,
            pera,
            m
      };
      System.out.println(new AnalizaObjekta().prikaz(osobe));
      System.out.println("---");

      PovezanaLista<String> ll1 = new PovezanaLista<>("baba");
      ll1.dodajElement("zaba");
      ll1.dodajElement("mika");
      ll1.dodajElement("zika");
      System.out.println(new AnalizaObjekta().prikaz(ll1));
      System.out.println("---");
   }
}
