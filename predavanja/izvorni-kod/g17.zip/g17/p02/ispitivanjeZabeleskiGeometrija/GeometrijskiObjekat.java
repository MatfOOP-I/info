package rs.math.oop.g17.p02.ispitivanjeZabeleskiGeometrija;

@PreambulaKlase(author = "Misa", date = "brrr.", reviewers = { "Петар", "Мики" })
public class GeometrijskiObjekat 
{
	
	private String oznaka;
	
	public void setOznaka(String o)
	{
		oznaka = o;
	}
	
	public String getOznaka()
	{
		return oznaka;
	}
	
	
}
