package rs.math.oop.g17.p02.ispitivanjeZabeleskiGeometrija;

public interface Prikaz
{
	void prikaziSe();
	
	void prikaziSe(java.awt.Graphics g);

}
