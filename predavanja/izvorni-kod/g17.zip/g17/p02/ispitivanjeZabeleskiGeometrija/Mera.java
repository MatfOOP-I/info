package rs.math.oop.g17.p02.ispitivanjeZabeleskiGeometrija;

public interface Mera
{
	
	public double obim();
	
	public double povrsina();
	
}