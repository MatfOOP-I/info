package rs.math.oop.g14.p11.enumerisaniSkup;

public enum DanUNedelji{
	PONEDELJAK, UTORAK, SREDA, CETVRTAK, PETAK, SUBOTA, NEDELJA;
}
