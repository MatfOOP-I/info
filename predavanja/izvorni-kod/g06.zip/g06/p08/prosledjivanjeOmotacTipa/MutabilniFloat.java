package rs.math.oop.g06.p08.prosledjivanjeOmotacTipa;

public class MutabilniFloat {
	float v;
	public MutabilniFloat(float value) {
		v=value;
	}

}
