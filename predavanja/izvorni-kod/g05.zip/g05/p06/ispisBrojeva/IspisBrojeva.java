package rs.math.oop.g05.p06.ispisBrojeva;

public class IspisBrojeva {

	public static void main(String[] args) {
		int broj = 1;
		while (broj <= 10) {
			System.out.print(broj + " ");
			broj++;
		}
		System.out.println();
	}
}
