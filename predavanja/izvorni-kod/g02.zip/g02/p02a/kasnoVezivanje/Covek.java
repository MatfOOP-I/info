package rs.math.oop.g02.p02a.kasnoVezivanje;

public class Covek {
    String ime;

    void stampajPodatke() {
        System.out.println("Име човека је: " + ime + ".");
    }
}
